Inspiration - new years resolution - draw once a day
  - this is hard
  - external motivation is nice

The idea
  -  

  Links
  - https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage
  - https://blog.logrocket.com/localstorage-javascript-complete-guide/
  - https://www.arclab.com/en/kb/htmlcss/display-date-time-javascript-php-ssi.html
  - 